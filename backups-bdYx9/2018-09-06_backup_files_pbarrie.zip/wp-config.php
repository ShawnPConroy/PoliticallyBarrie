<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'jsnowban_pbarrie_wp');

/** MySQL database username */
define('DB_USER', 'jsnowban_pbarrie');

/** MySQL database password */
define('DB_PASSWORD', 'cA3gd[U#46{d');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Gb[mAjF$3De(=*(){JA9?&u#TCWPM3b@Ox!KT8,b-+<KWo jNTgiP8`mO3zeIJD+');
define('SECURE_AUTH_KEY',  '}B5C8HcZd+S(.nu5Xge|b_7E{pDTsgj8*D<;P|4R,3`=d%nN7Z=T|be* tjD_-8e');
define('LOGGED_IN_KEY',    'MQn4]eI*fETdR+e$o?:S|.L9-=? WVi*0&;Kr,?f{n@mB.sm?%m-]nZ|%)P@7cR<');
define('NONCE_KEY',        'V~l0ct&0XNL7SI5.,Yc*#f+}NJB^tJ4<{E;-0k9yf[xWpnD&3MkAQ,qOz(* .[|P');
define('AUTH_SALT',        'rnu74C8k#bfUtIEKaB_5@sM*-$J_-o^dyeytIU4dH| %4FmkY0hn Y_.L[H|J|Au');
define('SECURE_AUTH_SALT', 'FSJZ)e5eOri3wyUzA:v5QkD`}q0-2&Q:#%&^JVFpee<16-?f$7t0Q1>;gp8uC+Jx');
define('LOGGED_IN_SALT',   'CI0>%Nl)Mh]E|p[1J<B}=M:o/u([C$`-VBtrkxrAB-)?/G-M@U.G6~#T.T,>/?XX');
define('NONCE_SALT',       '.A,KH_Xz4d=X ZT(FA|9Ux6#0GTjL-H+DiO(s1HG-^*<(:M#%:f.X8REofd0z,x|');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
