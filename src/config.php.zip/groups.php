<?php


/**
 * Display the groups yaml.
 */
function showGroups($app, $page)
{
  // Get representatives data
  $groupsData = yaml_parse_file($app['groupsFile']);
  processGroups($groupsData, $app, $page);
  if ($page['groups'] == false) exit("Failed to read groups data file.");
  include $app['templatePath'].'groups.php';
}




function processGroups ($groupsData, $app, &$page)
{
  foreach ($groupsData as $categoryName => $categoryGroups)
  {
    
    foreach ($categoryGroups as $groupName => $groupInfo)
    {
      if (!is_array($groupInfo)) continue;
      unset($currentGroup);
      $currentGroup['name'] = $groupName;
      $currentGroup['description'] = $groupInfo['Description'];
      $currentGroup['details'] = "";
      
      foreach ($groupInfo as $dataName => $dataDescription)
      {
        if ($dataName != 'Description')
        {
          $currentGroup['details'] .= generateDetailLi($dataName, $dataDescription, $app);
        }
        
      } // foreach data/detail
      $page['groups'][$categoryName][] = $currentGroup;
    } // foreach group
  } // foreach category
  return;
}



function generateDetailLi($dataName, $dataDescription, $app)
{
  $result = "";
  if ($dataName == 'Email')
  {
    $result .= '<li><a href="mailto:'.$dataDescription.'"><span class="fa-li fa fa-envelope" aria-label="email"></span> '.$dataDescription.'</a></li>';
  }
  else if ($dataName == 'Warning')
  {
    $result .= '<li><span class="fa-li fa fa-warning" aria-label="Warning"></span> '.$dataDescription.'</a></li>';
  }
  else if ($dataName == 'Phone' || $dataName == 'Fax')
  {
    switch ($dataName)
    {
      case 'Phone':
        $icon = 'phone';
        $ariaLabel = 'phone number';
        break;
      case 'Fax':
        $icon = 'fax';
        $ariaLabel = 'fax';
        break;
      case 'Address':
        $icon = 'map-marker';
        $ariaLabel = 'address';
        break;
    }
    $result .= '<li><span class="fa-li fa fa-'.$icon.'" aria-label="'.$ariaLabel.'"></span> '.$dataDescription.'</li>';
  }
  else if ($dataName == 'Address')
  {
    $result .= '<li><a href="https://www.google.ca/maps/place/'.strip_tags($dataDescription).'"><span class="fa-li fa fa-map-marker" aria-label="address"></span> '.$dataDescription.'</a></li>';
  }
  else if ($dataName == 'Facebook Group')
  {
    $result .= '<li><a href="'.strip_tags($dataDescription).'"><span class="fa-li fa fa-facebook" aria-label=""></span> Facebook Group</a></li>';
  }
  else if ($dataName == 'Facebook Page' || $dataName == 'Facebook Profile' || $dataName == 'Twitter' || $dataName == 'Instagram' || $dataName == 'LinkedIn')
  {
    switch ($dataName)
    {
      case 'Facebook Page':
        $icon = 'facebook';
        $ariaLabel = 'Facebook Page';
        break;
      case 'Facebook Profile':
        $icon = 'facebook';
        $ariaLabel = 'Facebook Profile';
        break;
      case 'Twitter':
        $icon = 'twitter';
        $ariaLabel = 'Twitter';
        break;
      case 'Instagram':
        $icon = 'instagram';
        $ariaLabel = 'Instagram';
        break;
      case 'LinkedIn':
        $icon = 'linkedin';
        $ariaLabel = 'Linked In';
        break;
    }
    
    // Get username
    $urlPath = explode('/', $dataDescription);
    while (empty($username = array_pop($urlPath)))
    {
      //Advance until true
    }
    
    $result .= '<li><a href="'.$dataDescription.'"><span class="fa-li fa fa-'.$icon.'" aria-label="'.$ariaLabel.'"></span> '.$username.'</a></li>';
    
  }
  else if (is_array($dataDescription) && key($dataDescription) == 'Link')
  {
    $result .= '<li><a href="'.current($dataDescription).'"><span class="fa-li fa fa-external-link" aria-label="web link"></span>'.$dataName.'</a></li>';
  }
  else if (!($dataName == 'Name' || $dataName == 'Party' || $dataName == 'Party Short Form' || $dataName == 'Office' || $dataName == 'Gender'))
  {
    $result .= "<li><strong>".$dataName."</strong>: ".$app['parsedown']->line($dataDescription)."</li>";
  }
  
  return $result;
}