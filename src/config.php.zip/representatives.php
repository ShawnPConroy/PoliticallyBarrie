<?php


/**
 * Shows the representatives.
 **/
function showReps($app, $page)
{
  // Get representatives data
  $repData = yaml_parse_file($app['repsFile']);
  if ($repData == false) exit("Failed to read representatives data file.");
  $location = $page['path'][2];
  getWardReps($repData['Wards'][$location], $app, $page);
  
  if( !empty($location) && !empty($repData['Wards'][$location]))
  {
    $page['pageTitle'] = "Your " . $repData['Wards'][$location]['Name'] . " Representatives";
    $page['pageTitleShort'] = $repData['Wards'][$location]['Name'] . " Representatives";
    $page['regionReps'] = $repData['Wards'][$location];

    include $app['templatePath'].'representatives-ward.php';
  }
  else
  {
    // Show list of all regions
    $page['pageTitle'] = "Barrie Representatives";
    $page['pageTitleShort'] = $pageTitle;
    if (!empty($location) && empty($repData['Wards'][$location]))
    {
      // Show error page saying the link is broken
      $page['pageContent'] = $pageContent = "Oops, it looks like the link you followed is broken. To find you elected representatives, select your ward from the list:";
    }
    else if (empty($location))
    {
      $page['pareContent'] = $pageContent = "To find you elected representatives, select your ward from the list:";
    }
    include $app['templatePath'].'representatives.php';
  }
}



function getWardReps($wardReps, $app, &$page)
{
  foreach($wardReps as $officeShort => $info)
  {
    // Skip if it's not an array of rep data
    if(is_array($info))
    {
      $contact = "";
      $links = "";
      unset($currentRep);
      
      // Collect details
      foreach($info as $key => $value)
      {
        if ($key == 'Email')
        {
          $contact .= '<li><a href="mailto:'.$value.'"><span class="fa-li fa fa-envelope" aria-label="email"></span> '.$value.'</a></li>';
        }
        else if ($key == 'Phone' || $key == 'Fax')
        {
          switch ($key)
          {
            case 'Phone':
              $icon = 'phone';
              $ariaLabel = 'phone number';
              break;
            case 'Fax':
              $icon = 'fax';
              $ariaLabel = 'fax';
              break;
            case 'Address':
              $icon = 'map-marker';
              $ariaLabel = 'address';
              break;
          }
          $contact .= '<li><span class="fa-li fa fa-'.$icon.'" aria-label="'.$ariaLabel.'"></span> '.$value.'</li>';
        }
        else if ($key == 'Address')
        {
          $contact .= '<li><a href="https://www.google.ca/maps/place/'.strip_tags($value).'"><span class="fa-li fa fa-map-marker" aria-label="address"></span> '.$value.'</a></li>';
        }
        else if ($key == 'Facebook Page' || $key == 'Facebook Profile' || $key == 'Twitter' || $key == 'Instagram' || $key == 'LinkedIn')
        {
          switch ($key)
          {
            case 'Facebook Page':
              $icon = 'facebook';
              $ariaLabel = 'Facebook Page';
              break;
            case 'Facebook Profile':
              $icon = 'facebook';
              $ariaLabel = 'Facebook Profile';
              break;
            case 'Twitter':
              $icon = 'twitter';
              $ariaLabel = 'Twitter';
              break;
            case 'Instagram':
              $icon = 'instagram';
              $ariaLabel = 'Instagram';
              break;
            case 'LinkedIn':
              $icon = 'linkedin';
              $ariaLabel = 'Linked In';
              break;
          }
          
          // Get username
          $urlPath = explode('/', $value);
          while (empty($username = array_pop($urlPath)))
          {
            //Advance until true
          }
          
          $links .= '<li><a href="'.$value.'"><span class="fa-li fa fa-'.$icon.'" aria-label="'.$ariaLabel.'"></span> '.$username.'</a></li>';
          
        }
        else if (is_array($value) && key($value) == 'Link')
        {
          $links .= '<li><a href="'.current($value).'"><span class="fa-li fa fa-external-link" aria-label="web link"></span>'.$key.'</a></li>';
        }
        else if (!($key == 'Name' || $key == 'Party' || $key == 'Party Short Form' || $key == 'Office' || $key == 'Gender'))
        {
          $links .= "<li><strong>".$key."</strong>: ".$app['parsedown']->line($value)."</li>";
        }
      } // end foreach $info
      
      switch ($info['Gender'])
      {
        case 'Male': $pronoun = "He"; break;
        case 'Female': $pronoun = "She"; break;
        default: $pronoun = "They"; break;
      }
      
      // Pull together rep data
      $summary = 'Your '.$info['Office'].' is '.$info['Name'].'.';
      if (!empty($info['Party']))
      {
        $summary .= ' '.$pronoun.' are a member of the '.$info['Party'].'.';
      }
      
      $currentRep['header'] = $officeShort.': '.$info['Name'];
      if (!empty($info['Party Short Form']))
      {
        $currentRep['header'] .= " (".$info['Party Short Form'].")";
      }
      $currentRep['contact'] = $contact;
      $currentRep['links'] = $links;
      $currentRep['summary'] = $summary;
      $currentRep['officeShort'] = $officeShort;
      $currentRep['id'] = makeId($officeShort);
      $wardRepsSummary[] = "<a href=\"#" . $currentRep['id'] . "\">" . $info['Name'] . "</a> (" . $officeShort . ")";
      $page['wardReps'][] = $currentRep;
    }
  } // end foreach $pageRepresentative
  
  
  // Sumarise ward reps
  $tempLast = array_pop($wardRepsSummary);
  $page['wardSummary'] = "Your representatives are " . implode(", ", $wardRepsSummary) . " and $tempLast.";
  
} // end function getWardReps();





// Based on www.mendoweb.be/blog/php-convert-string-to-camelcase-string/
function makeId($str, array $noStrip = [])
{
        // non-alpha and non-numeric characters become spaces
        $str = strtolower($str);
        $str = preg_replace('/[^a-z0-9' . implode("", $noStrip) . ']+/i', ' ', $str);
        $str = trim($str);
        // uppercase the first character of each word
        $str = ucwords($str);
        $str = str_replace(" ", "", $str);
        $str = lcfirst($str);

        return $str;
}