<?php

function showStats($app, $page)
{
  include $app['templatePath'].'stats.php';
}

/**
 * Displays home page.
 */
function showHome($app, $page)
{
  include $app['templatePath'].'home.php';
}


/**
 * Display 404
 */
function show404() {
  $page['pareContent'] = $pageContent = "Oops, it looks like the link you followed is broken. To find you elected representatives, select your ward from the list:";
  die($page['pareContent']);
  //include $app['templatePath'].'representatives-generic.php';
}


/**
 * Calls the appropriate function based on the url.
 */
function processRequest($app)
{
  $parsedUrl = parse_url($_SERVER['REQUEST_URI']);
  $page['path'] = explode('/', $parsedUrl['path']);
  

  $page['section'] = $page['path'][1];
  $page['siteTitle'] = $siteTitle = $app['siteTitle'];
  switch($page['section'])
  {
    case 'reps':
      showReps($app, $page);
      break;
    
    case 'vote':
      showVote($app, $page);
      break;
    
    case 'groups':
      showGroups($app, $page);
      break;
    
    case 'stats':
      showStats($app, $page);
      break;
    
    case '':
      showHome($app, $page);
      break;
    
    default:
      show404($app, $page);
      break;
  }
}