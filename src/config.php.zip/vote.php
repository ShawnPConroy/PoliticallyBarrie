<?php

/**
 * Show the election pages
 */
function showVote($app, $page)
{
  $pageTitle = "Barrie Elections";
  $election = $page['path'][2]; //$_REQUEST['election'];
  
  if ($election=="2011-federal" || $election=="2018-municipal" || $election=="2016-municipal" || $election=="2015-federal" || $election=="2014-municipal")
  {
    include $app['templatePath']."vote-$election.php";
  }
  else if ($election=='2018-provincial' || $election=='2014-provincial' || $election=='2011-provincial' || $election=='2007-provincial' )
  {
    showProvincialVote($election, $app, $page);
  }
  else if (empty($election))
  {
    include $app['templatePath'].'vote.php';
  }
}


function showProvincialVote($election, $app, $page)
{
    
  $voteData = yaml_parse_file($app['voteProvincialFile']);
  if ($voteData == false) exit("Failed to read provincial vote data file.");
  $page['voteData'] = $voteData[$election];
  include $app['templatePath']."vote-provincial.php";
  
}