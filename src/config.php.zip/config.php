<?php

include_once './lib/Parsedown.php';
include_once './src/request.php';
include_once './src/representatives.php';
include_once './src/groups.php';
include_once './src/vote.php';

$app['siteUrl'] = 'http://politicallybarrie.ca/';
$app['siteName'] = 'Politically Barrie';
$app['repsFile'] = './data/representatives.yaml';
$app['groupsFile'] = './data/groups.yaml';
$app['voteProvincialFile'] = './data/vote-provincial.yaml';
$app['templatePath'] = "./template/";
$app['imagesPath'] = $app['siteUrl']."images/";
$app['parsedown'] = new Parsedown();